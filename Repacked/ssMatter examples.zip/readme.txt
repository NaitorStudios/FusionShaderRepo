��SpriterSheet Matter
	by CallofAS


1) Extract the shader files "_ssMatter" to your Fusion \Effects directory
eg. D:\Program Files\Steam\steamapps\common\Clickteam Fusion 2.5\Effects

2) Make sure the image files are in the same folder as the .mfa

---

If you have more questions, try to reply to this thread.
https://community.clickteam.com/threads/106893-Shader-Shape-mask-with-sprite-sheets