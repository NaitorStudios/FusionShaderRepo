Open World Platformer
	by SolarB

1) Extract the shader files to your Fusion /Effects directory
2) Extract the .mfa and image files
3) Make sure the image files are in the same folder as the .mfa


Further help and instructions are in the .mfa